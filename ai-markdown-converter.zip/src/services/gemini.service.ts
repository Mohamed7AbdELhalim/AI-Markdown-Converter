import { Injectable, signal } from '@angular/core';
import { GoogleGenAI } from '@google/genai';

export interface FormatOption {
  value: string;
  name: string;
}

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI | undefined;
  isApiKeyMissing = signal<boolean>(false);

  constructor() {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      this.isApiKeyMissing.set(true);
      console.warn("API_KEY environment variable not set. The application will be in a disabled state.");
    } else {
      this.ai = new GoogleGenAI({ apiKey });
    }
  }

  async convertMarkdown(markdown: string, format: string): Promise<string> {
    if (this.isApiKeyMissing() || !this.ai) {
      throw new Error('لا يمكن إجراء التحويل لأن مفتاح API غير معين.');
    }

    const prompt = `
      You are an expert code converter. Your task is to convert the following Markdown text into valid ${format} code.
      - Respond ONLY with the raw code or markup.
      - Do not include any explanations, comments, or markdown formatting like \`\`\`${format.toLowerCase()}\`\`\` around the code.
      - If the format is 'HTML, CSS, & JS', create a single, self-contained HTML file with embedded CSS in a <style> tag and JavaScript in a <script> tag.

      Markdown to convert:
      ---
      ${markdown}
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          // Disable thinking for faster, lower-latency responses.
          thinkingConfig: { thinkingBudget: 0 },
        },
      });

      if (!response.text) {
        const finishReason = response.candidates?.[0]?.finishReason;
        if (finishReason && finishReason !== 'STOP') {
          throw new Error(`API returned no content. Reason: ${finishReason}. Please adjust your input.`);
        }
        throw new Error('The API returned an empty response. Please try again.');
      }

      return response.text.trim();
    } catch (error) {
      console.error('Error calling Gemini API:', error);
      // Propagate the original error so the component can display a specific message.
      if (error instanceof Error) {
        throw error;
      }
      throw new Error('An unknown error occurred while communicating with the API.');
    }
  }
}